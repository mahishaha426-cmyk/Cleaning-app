# CleanSmart AI — RSBVP 2026–27

Student project prototype for a Smart Village / Smart City cleanliness project.

## Included features
- Four screens: live object scan, cleanliness reports, collection task tracking, and progress score.
- Saves reports locally in the browser on this device.
- Uses the browser camera and a general-purpose COCO-SSD object detector.
- No photo upload or gallery picker.

## Important limitations
- The detector recognizes common objects; it is **not a custom waste-trained AI model**.
- A suggested waste category is only a heuristic and must be checked by a person.
- Reports are stored locally on the device and are not sent to a municipality or shared with other users.
- The prototype does not dispatch real sanitation workers or vehicles.

## Run locally
Camera access typically requires HTTPS or localhost. Opening `index.html` directly from a file manager may block camera access.

## Publish for mobile browser use (GitHub Pages)
1. Sign in to GitHub and create a new **public** repository, for example `cleansmart-ai`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to provide the HTTPS website address.
7. Open that HTTPS address in Chrome on your phone.
8. Tap **Start camera** and allow camera permission.

If the page fails to load the detector, check the internet connection and reload. The TensorFlow.js and COCO-SSD libraries are loaded from public CDNs.

## Suggested project demo
Use a few everyday objects in a safe, clean setup (e.g. a clean plastic bottle, book, apple). Demonstrate the live object detector, then manually confirm the suggested category and create a cleanliness report.
